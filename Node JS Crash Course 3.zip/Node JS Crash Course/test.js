const name = 'yoshi';

console.log(name);

const greet = (name) => {
    console.log(`hello`, $(name));
}

greet('mario');
greet('yoshi');
